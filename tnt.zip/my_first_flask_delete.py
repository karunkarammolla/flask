from flask import Flask,jsonify
from flask_sqlalchemy import SQLAlchemy,request
import psycopg2
import pandas as pd
import datetime
import pytz
import numpy as np
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:aEzES_9wESCUhhJ4@devinstance.cmmaelkfp8je.ap-south-1.rds.amazonaws.com/medidata'
app.debug = True
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db=SQLAlchemy(app)


last_updated_date = datetime.datetime.now(pytz.timezone('Asia/Calcutta'))
last_updated_date = last_updated_date.strftime("%Y-%m-%d %H:%M:%S")
last_updated_date = "'" + last_updated_date + "'"

@app.route('/inputdata',methods=['POST'])

def input():
    input_data = request.get_json()
    id = input_data['id']
    visit_id = input_data['visit_id']
    manual_patient_health_score = input_data['manual_patient_health_score']
    manual_reports_health_score = input_data['manual_reports_health_score']
    manual_assessment_health_score = input_data['manual_assessment_health_score']
    def main_fun(id, visit_id, manual_patient_health_score, manual_reports_health_score,
                 manual_assessment_health_score):
        db = databaseconnection()
        if db.isconnected:
            auth = db.auth_check("auth_users", "user_id", id)
            print("AUTH:::", auth)

            if auth in [4, 5]:
                check_point = db.visit_check('patient_health_score', 'patient_visit_id', visit_id)
                if len(check_point) > 0:

                    md = {'past_health_score': manual_patient_health_score,
                          'reports_health_score': manual_reports_health_score,
                          'assessment_health_score': manual_assessment_health_score}
                    manual_df = pd.DataFrame(md, index=[0])

                    check_point = check_point[['past_health_score', 'reports_health_score', 'assessment_health_score']]
                    manual_df = manual_df.replace('', np.NaN)
                    manual_df = manual_df.replace('null', np.NaN)
                    manual_df = manual_df.apply(pd.to_numeric, downcast='float', errors='ignore')

                    manual_df[manual_df.isnull()] = check_point

                    return db.update_api(id, visit_id, manual_df['past_health_score'][0],
                                         manual_df['reports_health_score'][0],
                                         manual_df['assessment_health_score'][0])

                else:
                    return jsonify({"status": 'You cannot update health score right now!! Please try again later'})
            else:
                return jsonify({"status": "You are not authorized to perform this action"})
        else:
            return jsonify({"status": 'Database connection failed. Please try it again.'})

    class databaseconnection:

        def __init__(self):
            self.isconnected = False
            try:
                self.connection = psycopg2.connect(
                    user="postgres",
                    password="aEzES_9wESCUhhJ4",
                    host='devinstance.cmmaelkfp8je.ap-south-1.rds.amazonaws.com',
                    port="5432",
                    database="medidata"
                )
                self.connection.autocommit = True
                self.cursor = self.connection.cursor()
                self.isconnected = True

            # except:
            except Exception as exc:
                pass
                # exec(pprint("can not connect database"))

        def auth_check(self, table_name, col_name, id):

            if self.isconnected:
                self.cursor.execute("select role_id from medidata.{} where {} = '{}'".format(table_name, col_name, id))
                sdf = self.cursor.fetchall()
                cols = list(map(lambda x: x[0], self.cursor.description))
                df = pd.DataFrame(sdf, columns=cols)

                return df['role_id'][0]

        def visit_check(self, table_name, col_name, visit_id):
            if self.isconnected:
                self.cursor.execute("select * from medidata.{} where {} ={}".format(table_name, col_name, visit_id))
                sdf = self.cursor.fetchall()
                cols = list(map(lambda x: x[0], self.cursor.description))
                df = pd.DataFrame(sdf, columns=cols)
                return df

        def update_api(self, id, visit_id, manual_patient_health_score, manual_reports_health_score,
                       manual_assessment_health_score):

            u_score = 1.0 * manual_assessment_health_score + 1.4 * manual_reports_health_score + 1.2 * manual_patient_health_score

            self.cursor.execute("""update medidata.patient_health_score as m set
                                          health_score = {},
                                          manual_patient_health_score = {},
                                          manual_reports_health_score = {},
                                          last_updated_by = '{}',
                                          last_updated_date ={},
                                          manual_assessment_health_score ={}
                                        where patient_visit_id = {}""".format(u_score, manual_patient_health_score,
                                                                              manual_reports_health_score,
                                                                              str(id),
                                                                              last_updated_date,
                                                                              manual_assessment_health_score, visit_id))
            self.connection.commit()
            return jsonify({'health_score': u_score})
            # return 'success'

    return main_fun(id, visit_id, manual_patient_health_score, manual_reports_health_score,
                                    manual_assessment_health_score)






