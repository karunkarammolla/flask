from flask import Flask,jsonify
from flask_sqlalchemy import SQLAlchemy,request
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:Ankitha@143@localhost/karanbase'
app.debug = True
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db=SQLAlchemy(app)



class movies(db.Model):
    __tablename__ = 'webapp_movies'
    id = db.Column(db.String(100),primary_key =True)
    movie_name = db.Column(db.String(100))
    language = db.Column(db.String(100))
    year = db.Column(db.Integer())

    def __init__(self,id,movie_name,language,year):
        self.id = id
        self.movie_name = movie_name
        self.language = language
        self.year = year

@app.route('/test', methods=['GET'])
def test():
    return 'my first trigger'
    # return{
    #     'test':'Ammolla Karunakar'
    # }

# @app.route('/webapp_movies',methods = ['GET'])
# def gmovies():
#     all_movies = movies.query.all()
#     output = []
#     for movie in all_movies:
#         currmovie={}
#         currmovie['id'] = movie.id
#         currmovie['movie_name'] = movie.movie_name
#         currmovie['language'] = movie.language
#         currmovie['year'] = movie.year
#         output.append(currmovie)
#     return jsonify(output)
#
# @app.route('/insert_movies',methods=['POST'])
# def pmovies():
#     moviedata = request.get_json()
#     movie = movies(id=moviedata['id'],movie_name=moviedata['movie_name'],language=moviedata['language'],year=moviedata['year'])#movies is clSS Nme
#     db.session.add(movie)
#     db.session.commit()
#     return jsonify(moviedata)
#
#
# @app.route('/update_movies/<id>',methods=['PUT'])
#
# def putmovies(id):
#     inmovie = movies.query.get_or_404(id)
#     moviedata = request.get_json()
#     inmovie.id = moviedata['id']
#     inmovie.movie_name = moviedata['movie_name']
#     inmovie.language = moviedata['language']
#     inmovie.year = moviedata['year']
#     db.session.add(inmovie)
#     db.session.commit()
#     return jsonify(moviedata)


@app.route('/movies/<id>',methods=['PUT','GET','POST','DELETE'])
def iammovies(id):
    inmovie = movies.query.get_or_404(id)


    # ***for single movie***
    # all_movies = movies.query.get_or_404(id)
    # output = []
    # # for movie in all_movies:
    # currmovie = {}
    # currmovie['id'] = all_movies.id
    # currmovie['movie_name'] = all_movies.movie_name
    # currmovie['language'] = all_movies.language
    # currmovie['year'] = all_movies.year
    # output.append(currmovie)
    # return jsonify(output)


    if request.method == 'GET':
        all_movies = movies.query.all()
        output = []
        for movie in all_movies:
            currmovie = {}
            currmovie['id'] = movie.id
            currmovie['movie_name'] = movie.movie_name
            currmovie['language'] = movie.language
            currmovie['year'] = movie.year
            output.append(currmovie)
        return jsonify(output)

    elif request.method == 'POST':
        moviedata = request.get_json()
        movie = movies(id=moviedata['id'], movie_name=moviedata['movie_name'], language=moviedata['language'],year=moviedata['year'])  # movies is clSS Nme
        db.session.add(movie)
        db.session.commit()
        return jsonify(moviedata)

    elif request.method == 'PUT':

        moviedata = request.get_json()
        inmovie.id = moviedata['id']
        inmovie.movie_name = moviedata['movie_name']
        inmovie.language = moviedata['language']
        inmovie.year = moviedata['year']
        db.session.add(inmovie)
        db.session.commit()
        return jsonify(moviedata)

    elif request.method == 'DELETE':
        db.session.delete(inmovie)
        db.session.commit()
        return jsonify({"message": f"movie {inmovie.movie_name} successfully deleted."})